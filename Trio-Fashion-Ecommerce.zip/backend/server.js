// Placeholder for secure Razorpay backend.
// Do NOT put Razorpay Key Secret in frontend files or GitHub Pages.
// Recommended deployment: a secure server/serverless function.
// Flow: create Razorpay Order -> return order_id -> Checkout -> verify signature -> save order.