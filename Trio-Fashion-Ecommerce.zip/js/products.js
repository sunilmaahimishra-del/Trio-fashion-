const products=[
{id:"tshirt",name:"T-Shirt",price:499,description:"Comfortable everyday T-Shirt."},
{id:"shirt",name:"Shirt",price:899,description:"Smart casual shirt for every occasion."},
{id:"dress",name:"Women's Dress",price:1099,description:"Stylish women's dress."},
{id:"jacket",name:"Jacket",price:1499,description:"Modern jacket for a premium look."}
];