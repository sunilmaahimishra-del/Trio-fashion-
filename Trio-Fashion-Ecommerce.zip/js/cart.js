function getCart(){return JSON.parse(localStorage.getItem('trioCart')||'[]')}
function saveCart(c){localStorage.setItem('trioCart',JSON.stringify(c));updateCartCount()}
function addToCart(id){const c=getCart();const item=c.find(x=>x.id===id);item?item.qty++:c.push({id,qty:1});saveCart(c);alert('Added to cart');}
function updateCartCount(){const n=getCart().reduce((s,x)=>s+x.qty,0);document.querySelectorAll('#cartCount').forEach(e=>e.textContent=n)}
function renderCart(){const box=document.getElementById('cartItems'),total=document.getElementById('cartTotal');let c=getCart();if(!c.length){box.innerHTML='<p>Your cart is empty.</p>';total.textContent='';return}
let sum=0;box.innerHTML=c.map(x=>{const p=products.find(y=>y.id===x.id);const v=p.price*x.qty;sum+=v;return `<div class="cart-row"><span>${p.name} × ${x.qty}</span><strong>₹${v.toLocaleString('en-IN')}</strong><button onclick="removeItem('${x.id}')">Remove</button></div>`}).join('');total.textContent='Total: ₹'+sum.toLocaleString('en-IN');updateCartCount()}
function removeItem(id){saveCart(getCart().filter(x=>x.id!==id));renderCart()} updateCartCount();